
# Gasto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**LocalDate**](LocalDate.md) |  |  [optional]
**descricao** | **String** |  |  [optional]
**id** | **Long** |  |  [optional]
**nome** | **String** |  |  [optional]
**tags** | **String** |  |  [optional]
**valor** | **Double** |  |  [optional]



